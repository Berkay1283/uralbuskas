const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kayıtkurulum')
        .setDescription('Kayıt kanalı ayarlayın ve kayıt mesajını gönderin')
        .addChannelOption(option =>
            option.setName('kanal')
                .setDescription('Kayıt kanalı')
                .setRequired(true)),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({ content: 'Bu komutu kullanmak için yönetici yetkisine sahip olmalısınız.', ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        const channel = interaction.options.getChannel('kanal');

        const embed = new EmbedBuilder()
            .setColor('#2bbbfe')
            .setTitle('KAYIT OL')
            .setDescription('Demo Bot Testing Sunucumuza Hoş Geldin!\nKayıt olmak için :flag_tr: veya :flag_gb: emojilerine tıklayabilirsin.')
            .setTimestamp();

        const kayıtMesajı = await channel.send({ embeds: [embed] });

        await kayıtMesajı.react('🇹🇷');
        await kayıtMesajı.react('🇬🇧');

        await interaction.editReply({ content: 'Kayıt mesajı başarıyla gönderildi!' });

        const filter = (reaction, user) => {
            return ['🇹🇷', '🇬🇧'].includes(reaction.emoji.name) && !user.bot;
        };

        const collector = kayıtMesajı.createReactionCollector({ filter, dispose: true });

        collector.on('collect', async (reaction, user) => {
            const member = await reaction.message.guild.members.fetch(user.id);
            if (reaction.emoji.name === '🇹🇷') {
                await member.roles.add('1267893675489361942');
                await member.roles.remove('1267893668518559776');
            } else if (reaction.emoji.name === '🇬🇧') {
                await member.roles.add('1267893668518559776');
                await member.roles.remove('1267893675489361942');
            }
        });

        collector.on('remove', async (reaction, user) => {
            const member = await reaction.message.guild.members.fetch(user.id);
            if (reaction.emoji.name === '🇹🇷') {
                await member.roles.remove('1267893675489361942');
            } else if (reaction.emoji.name === '🇬🇧') {
                await member.roles.remove('1267893668518559776');
            }
        });
    },
};
