const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Botun yanıt süresini kontrol eder.'),
    async execute(interaction) {
        await interaction.reply('Pong!');
    },
};
