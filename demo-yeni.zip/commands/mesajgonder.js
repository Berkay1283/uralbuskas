const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionsBitField, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mesajgonder')
        .setDescription('Girilen mesajı komutun kullanıldığı kanala gönderir.')
        .addStringOption(option => 
            option.setName('turkcemesaj')
                .setDescription('Gönderilecek Türkçe mesaj')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('ingilizcemesaj')
                .setDescription('Gönderilecek İngilizce mesaj')
                .setRequired(true)),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({ content: 'Bu komutu kullanmak için yönetici yetkisine sahip olmalısınız.', ephemeral: true });
        }

        const turkceMesaj = interaction.options.getString('turkcemesaj');
        const ingilizceMesaj = interaction.options.getString('ingilizcemesaj');

        // Görselleri ekle
        const backgroundPath = path.join(__dirname, '..', 'media', 'gokyuzubanner.png');
        const topRightPath = path.join(__dirname, '..', 'media', 'gokyuzu.png');

        const attachment = new AttachmentBuilder(backgroundPath, { name: 'gokyuzubanner.png' });
        const topRightImage = new AttachmentBuilder(topRightPath, { name: 'gokyuzu.png' });

        const embed = new EmbedBuilder()
            .setColor('#2bbbfe')
            .setTitle('Demo Bot System')
            .setDescription(`
                :flag_tr: **${turkceMesaj}**
                \n\n:flag_gb: **${ingilizceMesaj}**
            `)
            .setImage('attachment://gokyuzubanner.png')
            .setThumbnail('attachment://gokyuzu.png')
            .setTimestamp();

        try {
            await interaction.reply({ content: 'Mesaj başarıyla gönderildi!', ephemeral: true });
            await interaction.channel.send({ embeds: [embed], files: [attachment, topRightImage] });
        } catch (error) {
            console.error('Mesaj gönderilirken hata:', error);
            await interaction.followUp({ content: 'Mesaj gönderilirken bir hata oluştu!', ephemeral: true });
        }
    },
};
